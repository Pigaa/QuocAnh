/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PIGA
 */
import java.util.Collections;
import java.util.List;

public class MyRobot implements IRobot {
    @Override
    public int f1(List<Robot> t) {
        int sum = 0;
        for (Robot robot : t) {
            String label = robot.getLabel();
            if (!label.contains("A") && !label.contains("B")) {
                sum += robot.getStep();
            }
        }
        return sum;
    }

    @Override
    public void f2(List<Robot> t) {
        int maxStep = -1;
        for (Robot robot : t) {
            maxStep = Math.max(maxStep, robot.getStep());
        }
    }

    @Override
    public void f3(List<Robot> t) {
        Collections.sort(t, (r1, r2) -> {
            if (r1.getLabel().compareTo(r2.getLabel()) > 0) {
                return -1;
            } else if (r1.getLabel().compareTo(r2.getLabel()) < 0) {
                return 1;
            } else {
                return Integer.compare(r1.getStep(), r2.getStep());
            }
        });
    }
}
