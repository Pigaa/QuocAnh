/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PIGA
 */
public class Robot {
    private String label;
    private int step;

    public Robot() {
    }

    public Robot(String label, int step) {
        this.label = label;
        this.step = step;
    }

    String getLabel() {
        return label;
    }

    int getStep() {
        return step;
    }

    void setLabel(String label) {
        this.label = label;
    }

    void setStep(int step) {
        this.step = step;
    }
}
