/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PIGA
 */
public class MyString implements IString {
    @Override
    public int f1(String str) {
        int left = 0;
        int right = str.length() - 1;
        while (left < right) {
            if (str.charAt(left) != str.charAt(right)) {
                return 0; 
            }
            left++;
            right--;
        }
        return 1; 
    }

    @Override
    public String f2(String str) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            char currentChar = str.charAt(i);
            if (str.indexOf(currentChar) == i) {
                result.append(currentChar);
            }
        }
        return result.toString();
    }
}

